#include <stdio.h>
int main()
{
    int numbers[5];
    printf("Enter 5 integers:\n");
    for(int i = 0; i < 5; i++)
    {
        printf("Value %d: ", i + 1);
        scanf("%d", &numbers[i]);
    }
    printf("\nYou entered:\n");
    for(int i = 0; i < 5; i++)
    {
        printf("Value %d: %d\n", i + 1, numbers[i]);
    }
}
