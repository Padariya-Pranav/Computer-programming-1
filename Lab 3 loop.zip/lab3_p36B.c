#include <stdio.h>

int main() 
{
    int i, j;
    int left = 1, right = 5; 

    for(i = 1; i <= 6; i++) 
    { 
        printf("%d %d\n", left, right);

       
        if(i % 2 == 0) 
        {
            left++;
            right--;
        }
    }

    return 0;
}
