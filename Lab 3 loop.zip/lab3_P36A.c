#include <stdio.h>
int main() {
    int i, j;
    for (i = 1, j = 5; i <= 5; i++, j--) { // i increases, j decreases
        printf("%d %d\n", i, j);
    }
    return 0;
}
