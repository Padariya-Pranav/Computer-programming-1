#include<stdio.h>
void main()

{
int a,b,total=0;

for(a=1;a<=100; a++)
{
    if(a%13==0)
    {
        total= total +a;
    }
}
printf("%d is sum of the numbers divisible by 13 btwn 1 to 100\n", total);

}