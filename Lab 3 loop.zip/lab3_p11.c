#include<stdio.h>
void main()
{

    int a=1,b;
    do
    {
    
        printf("PRANAV \n");
        a++;
    } while (a<6);
    
    
}

