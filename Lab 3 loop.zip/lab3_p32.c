#include <stdio.h>

int main() {
    int i, j, count = 0;
    int isPrime;

    // Loop through numbers from 2 to 500
    for (i = 2; i <= 500; i++) {
        isPrime = 1; // Assume number is prime
        for (j = 2; j * j <= i; j++) { // Check divisibility up to sqrt(i)
            if (i % j == 0) {
                isPrime = 0; // Not prime
                break;
            }
        }
        if (isPrime) {
            count++; // Count the prime number
        }
    }

    printf(" Prime numbers between 1 and 500: %d\n", count);
    return 0;
}
