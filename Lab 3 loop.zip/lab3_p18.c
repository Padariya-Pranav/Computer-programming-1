#include <stdio.h>

int main() {
    char sex;
    int boys = 0, girls = 0, i;

    for (i = 1; i <= 50; i++)
    {
        printf("Enter sex of student %d (M/F): ", i);
        scanf(" %c", &sex);

        if (sex == 'M' )
            boys++;
        else if (sex == 'F' )
            girls++;
        else
            printf("please enter the gender as recommended\n");
    }

    printf("Total Boys: %d\n", boys);
    printf("Total Girls: %d\n", girls);

    return 0;
}